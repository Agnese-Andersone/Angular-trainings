import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lapa1',
  templateUrl: './lapa1.component.html',
  styleUrls: ['./lapa1.component.scss']
})
export class Lapa1Component implements OnInit {
  public counter: number = 1;
  constructor() { }
  
  ngOnInit(): void {
    this.counter = localStorage.getItem('counter')?
    parseInt(localStorage.getItem('counter')) : 0;
  }
 public increment(val){
   this.counter +=val;
   localStorage.setItem('counter', this.counter.toString());
 }
}
