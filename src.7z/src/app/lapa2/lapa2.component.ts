import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lapa2',
  templateUrl: './lapa2.component.html',
  styleUrls: ['./lapa2.component.scss']
})
export class Lapa2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
