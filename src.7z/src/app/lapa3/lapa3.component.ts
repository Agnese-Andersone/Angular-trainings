import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lapa3',
  templateUrl: './lapa3.component.html',
  styleUrls: ['./lapa3.component.scss']
})
export class Lapa3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
