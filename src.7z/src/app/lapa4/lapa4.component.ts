import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lapa4',
  templateUrl: './lapa4.component.html',
  styleUrls: ['./lapa4.component.scss']
})
export class Lapa4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
